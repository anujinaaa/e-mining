import{p as s}from"./DjnBaW9h.js";const t=s("/assets/images/icons/icon-star.svg"),a=s("/assets/images/icons/icon-star-yellow.svg");export{t as _,a};
