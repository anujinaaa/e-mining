import{p as s}from"./B4VRWHI3.js";const a=s("/assets/images/miner-2.png"),e=s("/assets/images/miner-3.png");export{a as _,e as a};
