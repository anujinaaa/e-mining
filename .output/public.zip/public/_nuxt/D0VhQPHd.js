import{p as s}from"./B4VRWHI3.js";const o=s("/assets/images/icons/icon-pine.svg");export{o as _};
