import{p as s}from"./B4VRWHI3.js";const p=s("/assets/images/thumbnail-12.png");export{p as _};
