import{p as s}from"./DjnBaW9h.js";const i=s("/assets/images/icons/icon-prev.svg"),t=s("/assets/images/icons/icon-next.svg");export{i as _,t as a};
