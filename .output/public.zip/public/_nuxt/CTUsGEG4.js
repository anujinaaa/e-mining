import{p as s}from"./B4VRWHI3.js";const i=s("/assets/images/icons/icon-prev.svg"),t=s("/assets/images/icons/icon-next.svg");export{i as _,t as a};
