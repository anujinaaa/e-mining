import{p as s}from"./B4VRWHI3.js";const t=s("/assets/images/avatar-9.png");export{t as _};
