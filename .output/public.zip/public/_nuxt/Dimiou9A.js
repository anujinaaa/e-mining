import{p as s}from"./B4VRWHI3.js";const t=s("/assets/images/icons/icon-star.svg"),a=s("/assets/images/icons/icon-star-yellow.svg");export{t as _,a};
