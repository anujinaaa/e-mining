import{p as s}from"./DjnBaW9h.js";const t=s("/assets/images/avatar-1.png");export{t as _};
