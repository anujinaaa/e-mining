import{p as s}from"./B4VRWHI3.js";const i=s("/assets/images/icons/icon-flower.svg"),a=s("/assets/images/icons/icon-map.svg");export{i as _,a};
