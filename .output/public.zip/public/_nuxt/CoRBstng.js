import{p as s}from"./DjnBaW9h.js";const o=s("/assets/images/icons/icon-pine.svg");export{o as _};
