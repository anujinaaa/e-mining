import{p as s}from"./DjnBaW9h.js";const p=s("/assets/images/thumbnail-5.png");export{p as _};
