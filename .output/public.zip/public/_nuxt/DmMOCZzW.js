import{p as s}from"./DjnBaW9h.js";const i=s("/assets/images/icons/icon-trees.svg"),t=s("/assets/images/icons/icon-sun.svg"),a=s("/assets/images/icons/icon-hat.svg");export{i as _,t as a,a as b};
