import{p as s}from"./B4VRWHI3.js";const c=s("/assets/images/icons/icon-check-gray.svg");export{c as _};
