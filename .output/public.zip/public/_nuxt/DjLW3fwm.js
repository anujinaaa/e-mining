import{p as s}from"./DjnBaW9h.js";const a=s("/assets/images/miner-2.png"),e=s("/assets/images/miner-3.png");export{a as _,e as a};
