import{_ as e}from"./B4VRWHI3.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
