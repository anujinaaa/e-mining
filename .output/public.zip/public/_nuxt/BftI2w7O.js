import{p as s}from"./DjnBaW9h.js";const a=s("/assets/images/icons/Icon-google.svg"),e=s("/assets/images/icons/icon-eye-gray.svg");export{a as _,e as a};
