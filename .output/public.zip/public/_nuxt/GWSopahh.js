import{p as s}from"./DjnBaW9h.js";const c=s("/assets/images/icons/icon-check-gray.svg");export{c as _};
