import{p as s}from"./DjnBaW9h.js";const t=s("/assets/images/icons/icon-button.svg"),a=s("/assets/images/dashboard.png");export{t as _,a};
