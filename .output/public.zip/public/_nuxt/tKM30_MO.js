import{p as s}from"./DjnBaW9h.js";const p=s("/assets/images/thumbnail-1.png");export{p as _};
