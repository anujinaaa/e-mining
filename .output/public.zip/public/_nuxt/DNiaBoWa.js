import{p as s}from"./DjnBaW9h.js";const t=s("/assets/images/avatar-12.png"),p=s("/assets/images/avatar-10.png");export{t as _,p as a};
