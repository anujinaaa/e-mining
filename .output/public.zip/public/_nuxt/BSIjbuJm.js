import{p as s}from"./DjnBaW9h.js";const i=s("/assets/images/icons/icon-flower.svg"),a=s("/assets/images/icons/icon-map.svg");export{i as _,a};
